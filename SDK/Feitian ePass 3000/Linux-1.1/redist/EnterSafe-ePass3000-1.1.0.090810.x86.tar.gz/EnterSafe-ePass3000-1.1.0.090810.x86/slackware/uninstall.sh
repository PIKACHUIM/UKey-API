#!/bin/bash
#
#
#

if [ -f /etc/rc.d/rc.inet2 ]; then
	declare -i start=0
	declare -i end=0
	declare -i headline=0 
	declare -i endline=0
	start=`cat /etc/rc.d/rc.inet2 -n | grep "Start the ngslotd daemon" | head -1 | cut -f1`
	if [ $start != 0 ]; then
		cp /etc/rc.d/rc.inet2 /etc/rc.d/rc.inet2.bak
		end=`cat /etc/rc.d/rc.inet2| wc -l`
		headline=$start-1
		endline=$end-$start-3
		head -n $headline /etc/rc.d/rc.inet2.bak > /etc/rc.d/rc.inet2
		tail -n $endline /etc/rc.d/rc.inet2.bak >> /etc/rc.d/rc.inet2
		rm /etc/rc.d/rc.inet2.bak
	fi
fi
