#!/bin/bash
#
#
#

if [ -f /etc/rc.d/rc.inet2 ]; then
	declare -i start=0
	start=`cat /etc/rc.d/rc.inet2 -n | grep "Start the ngslotd daemon" | head -1 | cut -f1`
	if [ $start == 0 ]; then
		echo "# Start the ngslotd daemon:"      >> /etc/rc.d/rc.inet2
		echo "if [ -x /etc/rc.d/rc.ngslotd ]; then"      >> /etc/rc.d/rc.inet2
		echo "    /etc/rc.d/rc.ngslotd start"      >> /etc/rc.d/rc.inet2
		echo "fi"      >> /etc/rc.d/rc.inet2
	fi
fi

